package com.artevaa.bacabuku

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Recent(val uri: String, val title: String, val type: String, val time: Long)

class ReaderTheme(val name: String, val bg: Int, val fg: Int, val bar: Int, val link: Int)

object Themes {
    val all = listOf(
        ReaderTheme("Terang", 0xFFFFFFFF.toInt(), 0xFF1F1F1F.toInt(), 0xFFEEEEEE.toInt(), 0xFF1A5FB4.toInt()),
        ReaderTheme("Sepia", 0xFFF4ECD8.toInt(), 0xFF4B3A2A.toInt(), 0xFFE6DCC2.toInt(), 0xFF8A4B08.toInt()),
        ReaderTheme("Gelap", 0xFF121212.toInt(), 0xFFD0D0D0.toInt(), 0xFF1E1E1E.toInt(), 0xFF8AB4F8.toInt())
    )

    fun get(i: Int): ReaderTheme = all[i.coerceIn(0, all.size - 1)]
}

class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("bacabuku", Context.MODE_PRIVATE)

    var theme: Int
        get() = sp.getInt("theme", 0)
        set(v) {
            sp.edit().putInt("theme", v).apply()
        }

    var fontPct: Int
        get() = sp.getInt("fontPct", 100)
        set(v) {
            sp.edit().putInt("fontPct", v).apply()
        }

    var translateOn: Boolean
        get() = sp.getBoolean("translateOn", false)
        set(v) {
            sp.edit().putBoolean("translateOn", v).apply()
        }

    fun savePos(key: String, a: Int, b: Float) {
        sp.edit().putInt("pa_$key", a).putFloat("pb_$key", b).apply()
    }

    fun posA(key: String): Int = sp.getInt("pa_$key", 0)

    fun posB(key: String): Float = sp.getFloat("pb_$key", 0f)

    fun recents(): List<Recent> {
        val list = ArrayList<Recent>()
        try {
            val arr = JSONArray(sp.getString("recents", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(Recent(o.getString("uri"), o.getString("title"), o.getString("type"), o.getLong("time")))
            }
        } catch (_: Exception) {
        }
        return list
    }

    private fun saveRecents(list: List<Recent>) {
        val arr = JSONArray()
        for (r in list) {
            arr.put(JSONObject().put("uri", r.uri).put("title", r.title).put("type", r.type).put("time", r.time))
        }
        sp.edit().putString("recents", arr.toString()).apply()
    }

    fun addRecent(r: Recent) {
        val list = recents().filter { it.uri != r.uri }.toMutableList()
        list.add(0, r)
        saveRecents(list.take(30))
    }

    fun removeRecent(uri: String) {
        saveRecents(recents().filter { it.uri != uri })
    }

    companion object {
        fun key(uri: String): String = Integer.toHexString(uri.hashCode())
    }
}
