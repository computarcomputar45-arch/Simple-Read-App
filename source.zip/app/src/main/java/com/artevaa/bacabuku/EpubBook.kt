package com.artevaa.bacabuku

import android.net.Uri
import android.text.Html
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.StringReader
import java.util.zip.ZipEntry
import java.util.zip.ZipFile

class TocItem(val title: String, val index: Int)

private class ManifestItem(val href: String, val type: String, val props: String)

class EpubBook(file: File) {
    val zip = ZipFile(file)
    var title: String = ""
    val spine = ArrayList<String>()
    val toc = ArrayList<TocItem>()
    private val lower = HashMap<String, String>()

    init {
        val en = zip.entries()
        while (en.hasMoreElements()) {
            val e = en.nextElement()
            lower[e.name.lowercase()] = e.name
        }
    }

    fun findEntry(path: String): ZipEntry? {
        val direct = zip.getEntry(path)
        if (direct != null) return direct
        val real = lower[path.lowercase()] ?: return null
        return zip.getEntry(real)
    }

    fun readText(path: String): String? {
        val e = findEntry(path) ?: return null
        val s = zip.getInputStream(e).use { String(it.readBytes(), Charsets.UTF_8) }
        return s.removePrefix("\uFEFF")
    }

    fun spineIndexOf(path: String): Int {
        val real = findEntry(path)?.name ?: return -1
        return spine.indexOf(real)
    }

    fun close() {
        try {
            zip.close()
        } catch (_: Exception) {
        }
    }

    fun load() {
        val container = readText("META-INF/container.xml")
            ?: throw IOException("Bukan file EPUB yang valid (container.xml tidak ada)")
        val rawOpf = Regex("full-path\\s*=\\s*\"([^\"]+)\"").find(container)?.groupValues?.get(1)
            ?: throw IOException("File EPUB rusak (OPF tidak ditemukan)")
        val opfPath = Uri.decode(rawOpf)
        val opfDir = dirOf(opfPath)
        val opf = readText(opfPath) ?: throw IOException("File EPUB rusak (OPF tidak bisa dibaca)")

        val items = HashMap<String, ManifestItem>()
        val spineIds = ArrayList<String>()
        var tocId: String? = null

        val parser = Xml.newPullParser()
        parser.setInput(StringReader(opf))
        var ev = parser.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                when (parser.name.substringAfter(':')) {
                    "item" -> {
                        val id = parser.getAttributeValue(null, "id")
                        val href = parser.getAttributeValue(null, "href")
                        if (id != null && href != null) {
                            items[id] = ManifestItem(
                                href,
                                parser.getAttributeValue(null, "media-type") ?: "",
                                parser.getAttributeValue(null, "properties") ?: ""
                            )
                        }
                    }
                    "itemref" -> {
                        val idref = parser.getAttributeValue(null, "idref")
                        if (idref != null) spineIds.add(idref)
                    }
                    "spine" -> {
                        tocId = parser.getAttributeValue(null, "toc")
                    }
                    "title" -> {
                        if (title.isEmpty()) {
                            try {
                                title = parser.nextText().trim()
                            } catch (_: Exception) {
                            }
                        }
                    }
                }
            }
            ev = parser.next()
        }

        for (id in spineIds) {
            val item = items[id] ?: continue
            val entry = findEntry(resolve(opfDir, item.href)) ?: continue
            spine.add(entry.name)
        }
        if (spine.isEmpty()) throw IOException("EPUB ini tidak punya isi yang bisa dibaca")

        val navItem = items.values.firstOrNull { it.props.split(' ').contains("nav") }
        val ncxById = if (tocId != null) items[tocId] else null
        val ncxItem = ncxById ?: items.values.firstOrNull { it.type == "application/x-dtbncx+xml" }
        try {
            if (navItem != null) parseNav(resolve(opfDir, navItem.href))
            if (toc.isEmpty() && ncxItem != null) parseNcx(resolve(opfDir, ncxItem.href))
        } catch (_: Exception) {
        }
        if (toc.isEmpty()) {
            for (i in spine.indices) toc.add(TocItem("Bagian ${i + 1}", i))
        }
    }

    private fun parseNav(navPath: String) {
        val text = readText(navPath) ?: return
        val dir = dirOf(navPath)
        val flags = setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)
        val block = Regex("<nav[^>]*toc[^>]*>(.*?)</nav>", flags).find(text)?.groupValues?.get(1) ?: text
        for (m in Regex("<a\\s[^>]*href\\s*=\\s*\"([^\"]*)\"[^>]*>(.*?)</a>", flags).findAll(block)) {
            addToc(dir, m.groupValues[1], m.groupValues[2])
        }
    }

    private fun parseNcx(ncxPath: String) {
        val text = readText(ncxPath) ?: return
        val dir = dirOf(ncxPath)
        val flags = setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)
        val re = Regex("<navPoint[^>]*>\\s*<navLabel>\\s*<text[^>]*>(.*?)</text>.*?<content[^>]*src\\s*=\\s*\"([^\"]*)\"", flags)
        for (m in re.findAll(text)) {
            addToc(dir, m.groupValues[2], m.groupValues[1])
        }
    }

    private fun addToc(dir: String, href: String, rawTitle: String) {
        if (href.startsWith("http")) return
        val file = href.substringBefore('#')
        if (file.isEmpty()) return
        val idx = spineIndexOf(resolve(dir, file))
        if (idx < 0) return
        val t = Html.fromHtml(rawTitle, Html.FROM_HTML_MODE_LEGACY).toString().replace(Regex("\\s+"), " ").trim()
        if (t.isEmpty()) return
        if (toc.isNotEmpty() && toc[toc.size - 1].index == idx) return
        toc.add(TocItem(t, idx))
    }

    companion object {
        fun dirOf(path: String): String = if (path.contains('/')) path.substringBeforeLast('/') else ""

        fun resolve(dir: String, href: String): String =
            normalize((if (dir.isEmpty()) "" else "$dir/") + Uri.decode(href))

        fun normalize(path: String): String {
            val out = ArrayList<String>()
            for (p in path.split('/')) {
                if (p.isEmpty() || p == ".") continue
                if (p == "..") {
                    if (out.isNotEmpty()) out.removeAt(out.size - 1)
                } else {
                    out.add(p)
                }
            }
            return out.joinToString("/")
        }
    }
}
