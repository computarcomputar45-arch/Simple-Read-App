package com.artevaa.bacabuku

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.widget.ImageView
import kotlin.math.abs

/** ImageView dengan pinch-zoom, geser, dan dobel-ketuk. Default: lebar halaman = lebar layar. */
class ZoomImageView(ctx: Context) : ImageView(ctx) {
    private val m = Matrix()
    private val v = FloatArray(9)
    private var base = 1f
    private var lastX = 0f
    private var lastY = 0f

    private val scaler = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            zoomBy(detector.scaleFactor, detector.focusX, detector.focusY)
            return true
        }
    })

    private val tapper = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true

        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (scaleNow() > base * 1.1f) fit() else zoomBy(2.5f, e.x, e.y)
            return true
        }
    })

    init {
        scaleType = ImageView.ScaleType.MATRIX
    }

    fun showBitmap(b: Bitmap?) {
        setImageBitmap(b)
        fit()
    }

    /** mode: 0 = normal, 1 = sepia, 2 = gelap (warna dibalik) */
    fun setFilterMode(mode: Int) {
        when (mode) {
            1 -> setColorFilter(
                ColorMatrixColorFilter(
                    ColorMatrix(
                        floatArrayOf(
                            0.96f, 0f, 0f, 0f, 0f,
                            0f, 0.90f, 0f, 0f, 0f,
                            0f, 0f, 0.75f, 0f, 0f,
                            0f, 0f, 0f, 1f, 0f
                        )
                    )
                )
            )
            2 -> setColorFilter(
                ColorMatrixColorFilter(
                    ColorMatrix(
                        floatArrayOf(
                            -1f, 0f, 0f, 0f, 255f,
                            0f, -1f, 0f, 0f, 255f,
                            0f, 0f, -1f, 0f, 255f,
                            0f, 0f, 0f, 1f, 0f
                        )
                    )
                )
            )
            else -> clearColorFilter()
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        fit()
    }

    private fun scaleNow(): Float {
        m.getValues(v)
        return v[Matrix.MSCALE_X]
    }

    fun fit() {
        val d = drawable ?: return
        if (width <= 0 || height <= 0 || d.intrinsicWidth <= 0 || d.intrinsicHeight <= 0) return
        base = width.toFloat() / d.intrinsicWidth
        m.reset()
        m.postScale(base, base)
        clamp()
        imageMatrix = m
    }

    private fun zoomBy(f: Float, fx: Float, fy: Float) {
        val cur = scaleNow()
        if (cur <= 0f) return
        val target = (cur * f).coerceIn(base, base * 5f)
        val real = target / cur
        m.postScale(real, real, fx, fy)
        clamp()
        imageMatrix = m
    }

    private fun clamp() {
        val d = drawable ?: return
        m.getValues(v)
        val s = v[Matrix.MSCALE_X]
        val w = d.intrinsicWidth * s
        val h = d.intrinsicHeight * s
        val curX = v[Matrix.MTRANS_X]
        val curY = v[Matrix.MTRANS_Y]
        val tx = if (w <= width) (width - w) / 2f else curX.coerceIn(width - w, 0f)
        val ty = if (h <= height) (height - h) / 2f else curY.coerceIn(height - h, 0f)
        m.postTranslate(tx - curX, ty - curY)
    }

    private fun pan(dx: Float, dy: Float) {
        val d = drawable ?: return
        m.getValues(v)
        val w = d.intrinsicWidth * v[Matrix.MSCALE_X]
        val tx = v[Matrix.MTRANS_X]
        val atLeft = tx >= -0.5f
        val atRight = tx <= width - w + 0.5f
        val blockedX = w <= width + 1f || (dx > 0 && atLeft) || (dx < 0 && atRight)
        if (abs(dx) > abs(dy) && blockedX) {
            parent?.requestDisallowInterceptTouchEvent(false)
        } else {
            parent?.requestDisallowInterceptTouchEvent(true)
        }
        m.postTranslate(dx, dy)
        clamp()
        imageMatrix = m
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaler.onTouchEvent(event)
        tapper.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = event.x
                lastY = event.y
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_POINTER_UP -> {
                val i = if (event.actionIndex == 0) 1 else 0
                lastX = event.getX(i)
                lastY = event.getY(i)
            }
            MotionEvent.ACTION_MOVE -> {
                if (!scaler.isInProgress && event.pointerCount == 1) {
                    val dx = event.x - lastX
                    val dy = event.y - lastY
                    lastX = event.x
                    lastY = event.y
                    pan(dx, dy)
                }
            }
        }
        return true
    }
}
