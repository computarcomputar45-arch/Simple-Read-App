package com.artevaa.bacabuku

import android.view.View
import android.widget.TextView

/** Bar terjemahan ala subtitle di bawah layar baca. */
class SubtitleBar(private val root: View, onPrev: () -> Unit, onNext: () -> Unit) {
    private val src: TextView = root.findViewById(R.id.subSource)
    private val txt: TextView = root.findViewById(R.id.subText)
    private val status: TextView = root.findViewById(R.id.subStatus)

    var token = 0
        private set

    init {
        root.findViewById<View>(R.id.subPrev).setOnClickListener { onPrev() }
        root.findViewById<View>(R.id.subNext).setOnClickListener { onNext() }
    }

    fun setVisible(v: Boolean) {
        root.visibility = if (v) View.VISIBLE else View.GONE
    }

    fun showHint(s: String) {
        token++
        src.text = ""
        txt.text = s
    }

    fun showSource(s: String): Int {
        token++
        src.text = s
        txt.text = "Menerjemahkan…"
        return token
    }

    fun showResult(s: String) {
        txt.text = s
    }

    fun showError(s: String) {
        txt.text = s
    }

    fun setStatus(s: String) {
        status.text = s
    }
}
