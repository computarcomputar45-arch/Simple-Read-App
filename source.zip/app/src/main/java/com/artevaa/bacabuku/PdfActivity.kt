package com.artevaa.bacabuku

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class PdfPageHolder(val iv: ZoomImageView) : RecyclerView.ViewHolder(iv) {
    var pageIndex = -1
}

class PdfActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var pager: ViewPager2
    private lateinit var root: View
    private lateinit var topBar: View
    private lateinit var bottomBar: View
    private lateinit var tvTitle: TextView
    private lateinit var tvInfo: TextView
    private lateinit var progress: ProgressBar
    private lateinit var subtitle: SubtitleBar
    private lateinit var barButtons: List<TextView>
    private lateinit var btnTranslate: TextView

    private var renderer: PdfRenderer? = null
    private var pfd: ParcelFileDescriptor? = null
    private val lock = Any()
    private val textLock = Any()
    private val renderExec: ExecutorService = Executors.newSingleThreadExecutor()
    private val textExec: ExecutorService = Executors.newSingleThreadExecutor()
    private var pdfFile: File? = null
    private var textDoc: PDDocument? = null

    private var pageCount = 0
    private var currentPage = 0
    private var posKey = ""

    private var chunks: List<String> = emptyList()
    private var chunkIdx = -1
    private var chunksPage = -1
    private var loadingPage = -1
    private var pendingSelect = 0

    @Volatile
    private var destroyed = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pdf)
        prefs = Prefs(this)
        val uri = intent.data
        if (uri == null) {
            finish()
            return
        }
        posKey = Prefs.key(uri.toString())

        root = findViewById(R.id.root)
        topBar = findViewById(R.id.topBar)
        bottomBar = findViewById(R.id.bottomBar)
        tvTitle = findViewById(R.id.tvTitle)
        tvInfo = findViewById(R.id.tvInfo)
        progress = findViewById(R.id.progress)
        pager = findViewById(R.id.pager)
        btnTranslate = findViewById(R.id.btnTranslate)
        barButtons = listOf(R.id.btnTheme, R.id.btnTranslate, R.id.btnPrevPg, R.id.btnNextPg)
            .map { findViewById<TextView>(it) }
        tvTitle.text = intent.getStringExtra("title") ?: "PDF"

        subtitle = SubtitleBar(findViewById<View>(R.id.subtitleRoot), { subPrev() }, { subNext() })

        findViewById<View>(R.id.btnTheme).setOnClickListener { showThemeDialog() }
        btnTranslate.setOnClickListener { setTranslate(!prefs.translateOn) }
        findViewById<View>(R.id.btnPrevPg).setOnClickListener {
            if (currentPage > 0) pager.setCurrentItem(currentPage - 1, true)
        }
        findViewById<View>(R.id.btnNextPg).setOnClickListener {
            if (currentPage + 1 < pageCount) pager.setCurrentItem(currentPage + 1, true)
        }
        tvInfo.setOnClickListener { showGoToDialog() }

        pager.offscreenPageLimit = 1
        applyTheme()
        subtitle.setVisible(prefs.translateOn)
        btnTranslate.alpha = if (prefs.translateOn) 1f else 0.45f
        if (prefs.translateOn) subtitle.showHint("Tekan ▶ untuk menerjemahkan halaman ini")

        progress.visibility = View.VISIBLE
        Thread {
            try {
                val f = FileUtil.cacheFile(this, uri, "pdf")
                val p = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
                val r = try {
                    PdfRenderer(p)
                } catch (e: Throwable) {
                    try {
                        p.close()
                    } catch (_: Exception) {
                    }
                    throw e
                }
                runOnUiThread {
                    if (isFinishing || destroyed) {
                        try {
                            r.close()
                            p.close()
                        } catch (_: Exception) {
                        }
                        return@runOnUiThread
                    }
                    onLoaded(f, p, r)
                }
            } catch (e: SecurityException) {
                fail("PDF ini dikunci dengan password (belum didukung).")
            } catch (e: Throwable) {
                fail("Gagal membuka PDF: " + (e.message ?: e.javaClass.simpleName))
            }
        }.start()
    }

    private fun fail(msg: String) {
        runOnUiThread {
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun onLoaded(f: File, p: ParcelFileDescriptor, r: PdfRenderer) {
        synchronized(lock) {
            renderer = r
            pfd = p
        }
        pdfFile = f
        pageCount = r.pageCount
        progress.visibility = View.GONE
        if (pageCount <= 0) {
            Toast.makeText(this, "PDF kosong", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        pager.adapter = PageAdapter()
        val start = prefs.posA(posKey).coerceIn(0, pageCount - 1)
        pager.setCurrentItem(start, false)
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                onPageChanged(position)
            }
        })
        onPageChanged(start)
    }

    // ---------- Render halaman ----------

    private fun targetWidth(): Int {
        val w = (resources.displayMetrics.widthPixels * 1.5f).toInt()
        return w.coerceIn(720, 1700)
    }

    private fun renderPage(i: Int, width: Int): Bitmap? {
        synchronized(lock) {
            val r = renderer ?: return null
            try {
                val page = r.openPage(i)
                try {
                    val h = (width.toFloat() * page.height / page.width).toInt().coerceAtLeast(1)
                    val bmp = Bitmap.createBitmap(width, h, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(Color.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    return bmp
                } finally {
                    page.close()
                }
            } catch (e: Throwable) {
                return null
            }
        }
    }

    inner class PageAdapter : RecyclerView.Adapter<PdfPageHolder>() {
        override fun getItemCount(): Int = pageCount

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PdfPageHolder {
            val iv = ZoomImageView(parent.context)
            iv.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            return PdfPageHolder(iv)
        }

        override fun onBindViewHolder(holder: PdfPageHolder, position: Int) {
            holder.pageIndex = position
            holder.iv.showBitmap(null)
            holder.iv.setFilterMode(prefs.theme)
            val width = targetWidth()
            renderExec.execute {
                if (holder.pageIndex != position) return@execute
                val bmp = renderPage(position, width)
                runOnUiThread {
                    if (!destroyed && holder.pageIndex == position && bmp != null) holder.iv.showBitmap(bmp)
                }
            }
        }

        override fun onViewRecycled(holder: PdfPageHolder) {
            holder.pageIndex = -1
            holder.iv.showBitmap(null)
        }
    }

    private fun onPageChanged(p: Int) {
        currentPage = p
        prefs.savePos(posKey, p, 0f)
        tvInfo.text = "Hal " + (p + 1) + " / " + pageCount
        chunks = emptyList()
        chunkIdx = -1
        chunksPage = -1
        if (prefs.translateOn) {
            if (pendingSelect == 0) subtitle.showHint("Tekan ▶ untuk menerjemahkan halaman ini")
            loadChunks(p)
        }
    }

    // ---------- Terjemahan ala subtitle ----------

    private fun setTranslate(on: Boolean) {
        prefs.translateOn = on
        subtitle.setVisible(on)
        btnTranslate.alpha = if (on) 1f else 0.45f
        if (on && pageCount > 0) {
            subtitle.showHint("Menyiapkan terjemahan…")
            Trans.prepare(
                { subtitle.setStatus("Model terjemahan siap") },
                { subtitle.setStatus(it) }
            )
            pendingSelect = 1
            loadChunks(currentPage)
        }
    }

    private fun extractText(page: Int): String {
        return try {
            synchronized(textLock) {
                val doc = textDoc ?: run {
                    PDFBoxResourceLoader.init(applicationContext)
                    val d = PDDocument.load(pdfFile)
                    textDoc = d
                    d
                }
                val s = PDFTextStripper()
                s.setSortByPosition(true)
                s.setStartPage(page + 1)
                s.setEndPage(page + 1)
                s.getText(doc)
            }
        } catch (e: Throwable) {
            ""
        }
    }

    private fun loadChunks(p: Int) {
        if (chunksPage == p) {
            applyPending()
            return
        }
        if (loadingPage == p) return
        loadingPage = p
        subtitle.setStatus("Membaca teks halaman…")
        textExec.execute {
            val text = extractText(p)
            runOnUiThread {
                if (destroyed) return@runOnUiThread
                if (loadingPage == p) loadingPage = -1
                if (p != currentPage) return@runOnUiThread
                chunks = splitChunks(text)
                chunkIdx = -1
                chunksPage = p
                applyPending()
            }
        }
    }

    private fun applyPending() {
        if (!prefs.translateOn) {
            pendingSelect = 0
            return
        }
        if (chunks.isEmpty()) {
            subtitle.setStatus("Halaman ini tidak punya teks (mungkin hasil scan)")
            pendingSelect = 0
            return
        }
        subtitle.setStatus(chunks.size.toString() + " bagian teks")
        val mode = pendingSelect
        pendingSelect = 0
        if (mode == 1) select(0) else if (mode == -1) select(chunks.size - 1)
    }

    private fun splitChunks(raw: String): List<String> {
        var t = raw.replace("\r", "")
        t = t.replace(Regex("-\\n(?=[a-z])"), "")
        val out = ArrayList<String>()
        for (para in t.split(Regex("\\n\\s*\\n"))) {
            val s = para.replace(Regex("\\s+"), " ").trim()
            if (s.length < 3) continue
            if (s.length <= 350) out.add(s) else out.addAll(chop(s))
        }
        return out
    }

    private fun chop(s: String): List<String> {
        val res = ArrayList<String>()
        val cur = StringBuilder()
        for (sent in s.split(Regex("(?<=[.!?])\\s+"))) {
            if (cur.isNotEmpty() && cur.length + sent.length + 1 > 350) {
                res.add(cur.toString())
                cur.setLength(0)
            }
            if (cur.isNotEmpty()) cur.append(' ')
            cur.append(sent)
            while (cur.length > 500) {
                res.add(cur.substring(0, 500))
                cur.delete(0, 500)
            }
        }
        if (cur.isNotEmpty()) res.add(cur.toString())
        return res
    }

    private fun select(i: Int) {
        if (i < 0 || i >= chunks.size) return
        chunkIdx = i
        val s = chunks[i]
        val tok = subtitle.showSource(s)
        subtitle.setStatus("Hal " + (currentPage + 1) + "  •  bagian " + (i + 1) + "/" + chunks.size)
        Trans.translate(s) { r, e ->
            if (subtitle.token != tok) return@translate
            if (r != null) subtitle.showResult(r) else subtitle.showError(e ?: "Gagal menerjemahkan")
        }
    }

    private fun subNext() {
        if (pageCount == 0) return
        if (chunksPage != currentPage) {
            pendingSelect = 1
            loadChunks(currentPage)
            return
        }
        if (chunkIdx + 1 < chunks.size) {
            select(chunkIdx + 1)
        } else if (currentPage + 1 < pageCount) {
            pendingSelect = 1
            pager.setCurrentItem(currentPage + 1, true)
        } else {
            subtitle.setStatus("Akhir dokumen")
        }
    }

    private fun subPrev() {
        if (pageCount == 0) return
        if (chunksPage != currentPage) {
            pendingSelect = 1
            loadChunks(currentPage)
            return
        }
        if (chunkIdx < 0 && chunks.isNotEmpty()) {
            select(0)
        } else if (chunkIdx > 0) {
            select(chunkIdx - 1)
        } else if (currentPage > 0) {
            pendingSelect = -1
            pager.setCurrentItem(currentPage - 1, true)
        }
    }

    // ---------- UI ----------

    private fun showGoToDialog() {
        if (pageCount == 0) return
        val et = EditText(this)
        et.inputType = InputType.TYPE_CLASS_NUMBER
        et.hint = "1 – $pageCount"
        AlertDialog.Builder(this)
            .setTitle("Ke halaman")
            .setView(et)
            .setPositiveButton("Buka") { _, _ ->
                val n = et.text.toString().toIntOrNull()
                if (n != null) pager.setCurrentItem((n - 1).coerceIn(0, pageCount - 1), false)
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun showThemeDialog() {
        val names = Array<CharSequence>(Themes.all.size) { Themes.all[it].name }
        AlertDialog.Builder(this)
            .setTitle("Tema")
            .setSingleChoiceItems(names, prefs.theme) { d, which ->
                prefs.theme = which
                applyTheme()
                d.dismiss()
            }
            .show()
    }

    private fun applyTheme() {
        val t = Themes.get(prefs.theme)
        root.setBackgroundColor(t.bg)
        pager.setBackgroundColor(t.bg)
        topBar.setBackgroundColor(t.bar)
        bottomBar.setBackgroundColor(t.bar)
        tvTitle.setTextColor(t.fg)
        tvInfo.setTextColor(t.fg)
        for (b in barButtons) b.setTextColor(t.fg)
        window.statusBarColor = t.bar
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = (prefs.theme != 2)
        pager.adapter?.notifyDataSetChanged()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (currentPage + 1 < pageCount) pager.setCurrentItem(currentPage + 1, false)
            return true
        }
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
            if (currentPage > 0) pager.setCurrentItem(currentPage - 1, false)
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN || keyCode == KeyEvent.KEYCODE_VOLUME_UP) return true
        return super.onKeyUp(keyCode, event)
    }

    override fun onPause() {
        super.onPause()
        if (pageCount > 0) prefs.savePos(posKey, currentPage, 0f)
    }

    override fun onDestroy() {
        destroyed = true
        renderExec.shutdownNow()
        textExec.shutdownNow()
        synchronized(lock) {
            try {
                renderer?.close()
            } catch (_: Exception) {
            }
            try {
                pfd?.close()
            } catch (_: Exception) {
            }
            renderer = null
            pfd = null
        }
        Thread {
            synchronized(textLock) {
                try {
                    textDoc?.close()
                } catch (_: Exception) {
                }
                textDoc = null
            }
        }.start()
        super.onDestroy()
    }
}
