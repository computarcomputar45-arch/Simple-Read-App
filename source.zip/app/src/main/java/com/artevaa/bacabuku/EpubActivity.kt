package com.artevaa.bacabuku

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.MimeTypeMap
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import org.json.JSONObject
import java.io.ByteArrayInputStream

class EpubActivity : AppCompatActivity() {

    companion object {
        const val HOST = "epub.local"

        private val SELF_CLOSE = Regex(
            "<(a|div|span|p|script|style|title|h[1-6]|b|i|em|strong|li|ul|ol|td|tr|table|section|nav|aside|label|button|textarea|iframe|center|font|small|sup|sub|u|blockquote|pre|code|cite)(\\s[^>]*?)?/>",
            RegexOption.IGNORE_CASE
        )

        private const val JS = """
(function(){
var SEL='p,li,h1,h2,h3,h4,h5,h6,blockquote,td,dd,dt,div,pre,figcaption';
var blocks=[],cur=-1;
window.bbTrans=false;
function collect(){
 blocks=[];
 if(!document.body)return;
 var all=document.body.querySelectorAll(SEL);
 for(var i=0;i<all.length;i++){
  var e=all[i];
  if(e.querySelector(SEL))continue;
  var t=(e.innerText||'').trim();
  if(t.length>1)blocks.push(e);
 }
}
function ensure(e){
 var r=e.getBoundingClientRect();
 if(r.top<60||r.bottom>window.innerHeight-20){e.scrollIntoView({block:'center'});}
}
function pick(i){
 if(i<0||i>=blocks.length)return;
 if(cur>=0&&blocks[cur])blocks[cur].classList.remove('bb-hl');
 cur=i;
 var e=blocks[i];
 e.classList.add('bb-hl');
 ensure(e);
 Android.onBlock((e.innerText||'').trim(),i,blocks.length);
}
function firstVisible(){
 for(var i=0;i<blocks.length;i++){
  if(blocks[i].getBoundingClientRect().bottom>60)return i;
 }
 return 0;
}
window.bbNext=function(){
 if(!blocks.length)collect();
 if(!blocks.length){Android.onEdge(1);return;}
 var i=cur<0?firstVisible():cur+1;
 if(i>=blocks.length){Android.onEdge(1);return;}
 pick(i);
};
window.bbPrev=function(){
 if(!blocks.length)collect();
 if(!blocks.length){Android.onEdge(-1);return;}
 var i=cur<0?firstVisible():cur-1;
 if(i<0){Android.onEdge(-1);return;}
 pick(i);
};
window.bbLast=function(){collect();if(blocks.length)pick(blocks.length-1);};
window.bbClear=function(){if(cur>=0&&blocks[cur])blocks[cur].classList.remove('bb-hl');cur=-1;};
window.bbSetTrans=function(v){window.bbTrans=v;if(!v)window.bbClear();};
window.bbSetCss=function(c){var s=document.getElementById('bb-style');if(s)s.textContent=c;};
document.addEventListener('click',function(ev){
 if(!window.bbTrans)return;
 var t=ev.target;
 if(!t||!t.closest)return;
 if(t.closest('a'))return;
 var e=t.closest(SEL);
 if(!e)return;
 if(!blocks.length)collect();
 var i=blocks.indexOf(e);
 if(i<0){collect();i=blocks.indexOf(e);}
 if(i>=0)pick(i);
},true);
var tm=0;
window.addEventListener('scroll',function(){
 if(tm)return;
 tm=setTimeout(function(){
  tm=0;
  var h=document.documentElement.scrollHeight-window.innerHeight;
  Android.onScroll(h>0?window.scrollY/h:0);
 },300);
});
})();
"""
    }

    private lateinit var prefs: Prefs
    private lateinit var web: WebView
    private lateinit var root: View
    private lateinit var topBar: View
    private lateinit var bottomBar: View
    private lateinit var tvTitle: TextView
    private lateinit var tvInfo: TextView
    private lateinit var progress: ProgressBar
    private lateinit var subtitle: SubtitleBar
    private lateinit var barButtons: List<TextView>
    private lateinit var btnTranslate: TextView

    @Volatile
    private var book: EpubBook? = null
    private var chapter = 0

    @Volatile
    private var ratio = 0.0
    private var restoreRatio = -1.0
    private var autoMode = 0
    private var posKey = ""

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_epub)
        prefs = Prefs(this)
        val uri = intent.data
        if (uri == null) {
            finish()
            return
        }
        posKey = Prefs.key(uri.toString())

        root = findViewById(R.id.root)
        topBar = findViewById(R.id.topBar)
        bottomBar = findViewById(R.id.bottomBar)
        tvTitle = findViewById(R.id.tvTitle)
        tvInfo = findViewById(R.id.tvInfo)
        progress = findViewById(R.id.progress)
        web = findViewById(R.id.web)
        btnTranslate = findViewById(R.id.btnTranslate)
        barButtons = listOf(
            R.id.btnToc, R.id.btnSmaller, R.id.btnBigger, R.id.btnTheme,
            R.id.btnTranslate, R.id.btnPrevCh, R.id.btnNextCh
        ).map { findViewById<TextView>(it) }
        tvTitle.text = intent.getStringExtra("title") ?: "EPUB"

        subtitle = SubtitleBar(findViewById<View>(R.id.subtitleRoot), { subtitleMove(-1) }, { subtitleMove(1) })

        findViewById<View>(R.id.btnToc).setOnClickListener { showToc() }
        findViewById<View>(R.id.btnSmaller).setOnClickListener { changeFont(-10) }
        findViewById<View>(R.id.btnBigger).setOnClickListener { changeFont(10) }
        findViewById<View>(R.id.btnTheme).setOnClickListener { showThemeDialog() }
        btnTranslate.setOnClickListener { setTranslate(!prefs.translateOn, true) }
        findViewById<View>(R.id.btnPrevCh).setOnClickListener { loadChapter(chapter - 1) }
        findViewById<View>(R.id.btnNextCh).setOnClickListener { loadChapter(chapter + 1) }

        setupWebView()
        applyTheme()
        setTranslate(prefs.translateOn, false)

        progress.visibility = View.VISIBLE
        Thread {
            try {
                val f = FileUtil.cacheFile(this, uri, "epub")
                val bk = EpubBook(f)
                bk.load()
                runOnUiThread {
                    if (isFinishing || isDestroyed) {
                        bk.close()
                        return@runOnUiThread
                    }
                    book = bk
                    if (bk.title.isNotEmpty()) tvTitle.text = bk.title
                    chapter = prefs.posA(posKey).coerceIn(0, bk.spine.size - 1)
                    restoreRatio = prefs.posB(posKey).toDouble()
                    loadChapter(chapter, keepRestore = true)
                }
            } catch (e: Throwable) {
                runOnUiThread {
                    Toast.makeText(this, "Gagal membuka EPUB: " + (e.message ?: e.javaClass.simpleName), Toast.LENGTH_LONG).show()
                    finish()
                }
            }
        }.start()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = false
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.textZoom = prefs.fontPct
        s.setSupportZoom(false)
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val u = request?.url ?: return null
                if (u.host != HOST) {
                    return WebResourceResponse("text/plain", "UTF-8", ByteArrayInputStream(ByteArray(0)))
                }
                return serve(u.path ?: "")
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u = request?.url ?: return true
                if (u.host == HOST) return false
                if (u.scheme == "http" || u.scheme == "https") {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, u))
                    } catch (_: Exception) {
                    }
                }
                return true
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                progress.visibility = View.GONE
                val bk = book
                if (bk != null && url != null) {
                    val path = Uri.parse(url).path ?: ""
                    val idx = bk.spineIndexOf(EpubBook.normalize(path))
                    if (idx >= 0) chapter = idx
                }
                web.evaluateJavascript("bbSetTrans(" + prefs.translateOn + ")", null)
                if (restoreRatio >= 0) {
                    val r = restoreRatio
                    restoreRatio = -1.0
                    web.postDelayed({
                        web.evaluateJavascript(
                            "(function(){var h=document.documentElement.scrollHeight-window.innerHeight;window.scrollTo(0,h>0?h*" + r + ":0);})()",
                            null
                        )
                    }, 250)
                }
                if (autoMode != 0) {
                    val m = autoMode
                    autoMode = 0
                    web.postDelayed({ web.evaluateJavascript(if (m == 1) "bbNext()" else "bbLast()", null) }, 350)
                }
                updateInfo()
            }
        }
    }

    // ---------- Menyajikan isi EPUB ke WebView ----------

    private fun notFound(): WebResourceResponse =
        WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", emptyMap(), ByteArrayInputStream(ByteArray(0)))

    private fun serve(rawPath: String): WebResourceResponse {
        val bk = book ?: return notFound()
        val path = EpubBook.normalize(rawPath)
        val entry = bk.findEntry(path) ?: return notFound()
        val lower = path.lowercase()
        return try {
            if (lower.endsWith(".xhtml") || lower.endsWith(".html") || lower.endsWith(".htm")) {
                val raw = bk.zip.getInputStream(entry).use { it.readBytes() }
                val html = injectHtml(String(raw, Charsets.UTF_8))
                WebResourceResponse("text/html", "UTF-8", ByteArrayInputStream(html.toByteArray(Charsets.UTF_8)))
            } else {
                WebResourceResponse(mimeFor(lower), null, bk.zip.getInputStream(entry))
            }
        } catch (e: Exception) {
            notFound()
        }
    }

    private fun mimeFor(p: String): String {
        val ext = p.substringAfterLast('.', "")
        return when (ext) {
            "css" -> "text/css"
            "js" -> "application/javascript"
            "svg" -> "image/svg+xml"
            "ttf" -> "font/ttf"
            "otf" -> "font/otf"
            "woff" -> "font/woff"
            "woff2" -> "font/woff2"
            "jpg", "jpeg" -> "image/jpeg"
            "png" -> "image/png"
            "gif" -> "image/gif"
            "webp" -> "image/webp"
            else -> MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
        }
    }

    private fun hex(c: Int): String = String.format("#%06X", c and 0xFFFFFF)

    private fun currentCss(): String {
        val t = Themes.get(prefs.theme)
        val bg = hex(t.bg)
        val fg = hex(t.fg)
        val link = hex(t.link)
        val force = if (prefs.theme != 0) "body *{color:" + fg + " !important;background-color:transparent !important;}" else ""
        return "html,body{background:" + bg + " !important;color:" + fg + " !important;}" +
            "body{padding:10px 16px 40px 16px !important;margin:0 !important;line-height:1.55 !important;max-width:100% !important;overflow-wrap:break-word;}" +
            force +
            "a,a *{color:" + link + " !important;}" +
            "img,svg,video{max-width:100% !important;height:auto !important;}" +
            "body .bb-hl,.bb-hl{background-color:rgba(255,193,7,0.35) !important;border-radius:4px;}"
    }

    private fun injectHtml(html: String): String {
        val fixed = SELF_CLOSE.replace(html) { m ->
            "<" + m.groupValues[1] + m.groupValues[2] + "></" + m.groupValues[1] + ">"
        }
        val inject = "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">" +
            "<style id=\"bb-style\">" + currentCss() + "</style><script>" + JS + "</script>"
        val head = Regex("<head(\\s[^>]*)?>", RegexOption.IGNORE_CASE).find(fixed)
        if (head != null) {
            val p = head.range.last + 1
            return fixed.substring(0, p) + inject + fixed.substring(p)
        }
        val htmlTag = Regex("<html(\\s[^>]*)?>", RegexOption.IGNORE_CASE).find(fixed)
        if (htmlTag != null) {
            val p = htmlTag.range.last + 1
            return fixed.substring(0, p) + "<head>" + inject + "</head>" + fixed.substring(p)
        }
        return "<head>$inject</head>$fixed"
    }

    // ---------- Jembatan JavaScript -> Android ----------

    inner class Bridge {
        @JavascriptInterface
        fun onBlock(text: String, idx: Int, total: Int) {
            runOnUiThread { handleBlock(text, idx, total) }
        }

        @JavascriptInterface
        fun onEdge(dir: Int) {
            runOnUiThread { handleEdge(dir) }
        }

        @JavascriptInterface
        fun onScroll(r: Double) {
            ratio = r
            runOnUiThread { updateInfo() }
        }
    }

    private fun handleBlock(text: String, idx: Int, total: Int) {
        if (!prefs.translateOn) return
        val tok = subtitle.showSource(text)
        subtitle.setStatus("Paragraf " + (idx + 1) + "/" + total)
        Trans.translate(text) { r, e ->
            if (subtitle.token != tok) return@translate
            if (r != null) subtitle.showResult(r) else subtitle.showError(e ?: "Gagal menerjemahkan")
        }
    }

    private fun handleEdge(dir: Int) {
        val bk = book ?: return
        if (dir > 0 && chapter + 1 < bk.spine.size) {
            autoMode = 1
            loadChapter(chapter + 1)
        } else if (dir < 0 && chapter > 0) {
            autoMode = 2
            loadChapter(chapter - 1)
        } else {
            subtitle.setStatus(if (dir > 0) "Akhir buku" else "Awal buku")
        }
    }

    private fun subtitleMove(dir: Int) {
        web.evaluateJavascript(if (dir > 0) "bbNext()" else "bbPrev()", null)
    }

    // ---------- Navigasi & pengaturan ----------

    private fun loadChapter(i: Int, keepRestore: Boolean = false) {
        val bk = book ?: return
        if (i < 0 || i >= bk.spine.size) return
        chapter = i
        ratio = 0.0
        if (!keepRestore) restoreRatio = -1.0
        progress.visibility = View.VISIBLE
        web.loadUrl("https://" + HOST + "/" + Uri.encode(bk.spine[i], "/"))
        updateInfo()
    }

    private fun updateInfo() {
        val bk = book ?: return
        val pct = (ratio * 100).toInt().coerceIn(0, 100)
        tvInfo.text = "Bab " + (chapter + 1) + "/" + bk.spine.size + "  •  " + pct + "%"
    }

    private fun showToc() {
        val bk = book ?: return
        val items = Array<CharSequence>(bk.toc.size) { bk.toc[it].title }
        AlertDialog.Builder(this)
            .setTitle("Daftar isi")
            .setItems(items) { _, which -> loadChapter(bk.toc[which].index) }
            .show()
    }

    private fun changeFont(delta: Int) {
        val v = (prefs.fontPct + delta).coerceIn(60, 260)
        prefs.fontPct = v
        web.settings.textZoom = v
        Toast.makeText(this, "Ukuran teks $v%", Toast.LENGTH_SHORT).show()
    }

    private fun showThemeDialog() {
        val names = Array<CharSequence>(Themes.all.size) { Themes.all[it].name }
        AlertDialog.Builder(this)
            .setTitle("Tema")
            .setSingleChoiceItems(names, prefs.theme) { d, which ->
                prefs.theme = which
                applyTheme()
                d.dismiss()
            }
            .show()
    }

    private fun applyTheme() {
        val t = Themes.get(prefs.theme)
        root.setBackgroundColor(t.bg)
        topBar.setBackgroundColor(t.bar)
        bottomBar.setBackgroundColor(t.bar)
        tvTitle.setTextColor(t.fg)
        tvInfo.setTextColor(t.fg)
        for (b in barButtons) b.setTextColor(t.fg)
        web.setBackgroundColor(t.bg)
        window.statusBarColor = t.bar
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = (prefs.theme != 2)
        web.evaluateJavascript("bbSetCss(" + JSONObject.quote(currentCss()) + ")", null)
        btnTranslate.alpha = if (prefs.translateOn) 1f else 0.45f
    }

    private fun setTranslate(on: Boolean, fromUser: Boolean) {
        prefs.translateOn = on
        subtitle.setVisible(on)
        btnTranslate.alpha = if (on) 1f else 0.45f
        if (fromUser) web.evaluateJavascript("bbSetTrans($on)", null)
        if (on) {
            subtitle.showHint("Ketuk sebuah paragraf untuk melihat terjemahannya, atau tekan ▶ untuk mulai dari paragraf yang terlihat.")
            Trans.prepare(
                { subtitle.setStatus("Model terjemahan siap") },
                { subtitle.setStatus(it) }
            )
            if (fromUser) web.evaluateJavascript("bbNext()", null)
        }
    }

    private fun pageBy(dir: Int) {
        if (dir > 0) {
            if (web.canScrollVertically(1)) web.pageDown(false) else loadChapter(chapter + 1)
        } else {
            if (web.canScrollVertically(-1)) web.pageUp(false) else if (chapter > 0) loadChapter(chapter - 1)
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            pageBy(1)
            return true
        }
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
            pageBy(-1)
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN || keyCode == KeyEvent.KEYCODE_VOLUME_UP) return true
        return super.onKeyUp(keyCode, event)
    }

    override fun onPause() {
        super.onPause()
        if (book != null) prefs.savePos(posKey, chapter, ratio.toFloat())
        web.onPause()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
    }

    override fun onDestroy() {
        try {
            web.stopLoading()
            web.destroy()
        } catch (_: Exception) {
        }
        book?.close()
        book = null
        super.onDestroy()
    }
}
