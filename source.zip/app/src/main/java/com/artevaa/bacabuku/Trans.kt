package com.artevaa.bacabuku

import android.util.LruCache
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions

/** Terjemahan Inggris -> Indonesia, berjalan di perangkat (ML Kit). Butuh internet hanya untuk mengunduh model sekali. */
object Trans {
    private val translator: Translator by lazy {
        Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.INDONESIAN)
                .build()
        )
    }
    private val cache = LruCache<String, String>(400)

    @Volatile
    private var ready = false

    fun prepare(onOk: () -> Unit, onFail: (String) -> Unit) {
        ensureModel(onOk, onFail)
    }

    private fun ensureModel(ok: () -> Unit, fail: (String) -> Unit) {
        if (ready) {
            ok()
            return
        }
        translator.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                ready = true
                ok()
            }
            .addOnFailureListener {
                fail("Model terjemahan belum terunduh. Sambungkan internet sekali (±30 MB), lalu coba lagi.")
            }
    }

    /** Callback selalu dipanggil di main thread: (hasil, pesanError). */
    fun translate(text: String, cb: (String?, String?) -> Unit) {
        val clean = text.trim().replace(Regex("\\s+"), " ")
        if (clean.isEmpty()) {
            cb("", null)
            return
        }
        val cached = cache.get(clean)
        if (cached != null) {
            cb(cached, null)
            return
        }
        ensureModel({
            val parts = split(clean)
            val out = StringBuilder()
            fun step(i: Int) {
                if (i >= parts.size) {
                    val r = out.toString().trim()
                    cache.put(clean, r)
                    cb(r, null)
                    return
                }
                translator.translate(parts[i])
                    .addOnSuccessListener {
                        out.append(it).append(' ')
                        step(i + 1)
                    }
                    .addOnFailureListener {
                        cb(null, it.message ?: "Gagal menerjemahkan")
                    }
            }
            step(0)
        }, { err -> cb(null, err) })
    }

    private fun split(t: String): List<String> {
        if (t.length <= 450) return listOf(t)
        val sentences = t.split(Regex("(?<=[.!?…])\\s+"))
        val res = ArrayList<String>()
        val cur = StringBuilder()
        for (s in sentences) {
            if (cur.isNotEmpty() && cur.length + s.length + 1 > 450) {
                res.add(cur.toString())
                cur.setLength(0)
            }
            if (cur.isNotEmpty()) cur.append(' ')
            cur.append(s)
            while (cur.length > 600) {
                res.add(cur.substring(0, 600))
                cur.delete(0, 600)
            }
        }
        if (cur.isNotEmpty()) res.add(cur.toString())
        return res
    }
}
