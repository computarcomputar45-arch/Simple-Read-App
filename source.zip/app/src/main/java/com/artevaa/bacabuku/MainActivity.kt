package com.artevaa.bacabuku

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.text.DateFormat
import java.util.Date

class MainActivity : AppCompatActivity() {
    private lateinit var prefs: Prefs
    private lateinit var list: ListView
    private lateinit var empty: TextView
    private var items: List<Recent> = emptyList()

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) openUri(uri, true)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)
        list = findViewById(R.id.list)
        empty = findViewById(R.id.tvEmpty)

        findViewById<View>(R.id.btnOpen).setOnClickListener { picker.launch(arrayOf("*/*")) }
        list.setOnItemClickListener { _, _, pos, _ ->
            items.getOrNull(pos)?.let { openUri(Uri.parse(it.uri), false) }
        }
        list.setOnItemLongClickListener { _, _, pos, _ ->
            items.getOrNull(pos)?.let {
                prefs.removeRecent(it.uri)
                refresh()
                Toast.makeText(this, "Dihapus dari daftar", Toast.LENGTH_SHORT).show()
            }
            true
        }

        Thread { FileUtil.trimCache(applicationContext) }.start()

        if (savedInstanceState == null) {
            val d = intent?.data
            if (intent?.action == Intent.ACTION_VIEW && d != null) openUri(d, false)
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        items = prefs.recents()
        empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        list.adapter = object : ArrayAdapter<Recent>(
            this@MainActivity, android.R.layout.simple_list_item_2, android.R.id.text1, items
        ) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getView(position, convertView, parent)
                val r = getItem(position)
                if (r != null) {
                    v.findViewById<TextView>(android.R.id.text1).text = r.title
                    v.findViewById<TextView>(android.R.id.text2).text =
                        r.type.uppercase() + "  •  " + DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(r.time))
                }
                return v
            }
        }
    }

    private fun openUri(uri: Uri, persist: Boolean) {
        if (persist) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {
            }
        }
        val name = FileUtil.displayName(this, uri)
        val type = FileUtil.detectType(this, uri, name)
        if (type == null) {
            Toast.makeText(this, "Format tidak didukung. Pilih file .epub atau .pdf", Toast.LENGTH_LONG).show()
            return
        }
        val title = name.substringBeforeLast('.')
        prefs.addRecent(Recent(uri.toString(), title, type, System.currentTimeMillis()))
        val i = Intent(this, if (type == "pdf") PdfActivity::class.java else EpubActivity::class.java)
        i.data = uri
        i.putExtra("title", title)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(i)
    }
}
