package com.artevaa.bacabuku

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

object FileUtil {

    fun displayName(ctx: Context, uri: Uri): String {
        var name: String? = null
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) name = c.getString(i)
                }
            }
        } catch (_: Exception) {
        }
        return name ?: uri.lastPathSegment?.substringAfterLast('/') ?: "buku"
    }

    private fun querySize(ctx: Context, uri: Uri): Long {
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val i = c.getColumnIndex(OpenableColumns.SIZE)
                    if (i >= 0 && !c.isNull(i)) return c.getLong(i)
                }
            }
        } catch (_: Exception) {
        }
        return -1L
    }

    /** Mengembalikan "pdf", "epub", atau null bila format tidak dikenali. */
    fun detectType(ctx: Context, uri: Uri, name: String): String? {
        val n = name.lowercase()
        if (n.endsWith(".pdf")) return "pdf"
        if (n.endsWith(".epub")) return "epub"
        try {
            val mime = ctx.contentResolver.getType(uri)
            if (mime == "application/pdf") return "pdf"
            if (mime == "application/epub+zip") return "epub"
        } catch (_: Exception) {
        }
        try {
            ctx.contentResolver.openInputStream(uri)?.use { s ->
                val b = ByteArray(4)
                val r = s.read(b)
                if (r == 4) {
                    if (b[0] == '%'.code.toByte() && b[1] == 'P'.code.toByte() && b[2] == 'D'.code.toByte() && b[3] == 'F'.code.toByte()) return "pdf"
                    if (b[0] == 'P'.code.toByte() && b[1] == 'K'.code.toByte()) return "epub"
                }
            }
        } catch (_: Exception) {
        }
        return null
    }

    /** Menyalin file dari content:// ke cache agar bisa dibaca acak (EPUB = zip, PDF = PdfRenderer). */
    fun cacheFile(ctx: Context, uri: Uri, ext: String): File {
        val dir = File(ctx.cacheDir, "books")
        dir.mkdirs()
        val f = File(dir, Integer.toHexString(uri.toString().hashCode()) + "." + ext)
        val size = querySize(ctx, uri)
        if (f.exists() && f.length() > 0 && (size <= 0 || f.length() == size)) {
            f.setLastModified(System.currentTimeMillis())
            return f
        }
        val tmp = File(dir, f.name + ".tmp")
        val input = ctx.contentResolver.openInputStream(uri) ?: throw IOException("Tidak bisa membuka file")
        input.use { ins ->
            FileOutputStream(tmp).use { out -> ins.copyTo(out) }
        }
        if (f.exists()) f.delete()
        if (!tmp.renameTo(f)) throw IOException("Gagal menyimpan salinan file")
        return f
    }

    fun trimCache(ctx: Context) {
        try {
            val files = File(ctx.cacheDir, "books").listFiles() ?: return
            files.sortedByDescending { it.lastModified() }.drop(8).forEach { it.delete() }
        } catch (_: Exception) {
        }
    }
}
